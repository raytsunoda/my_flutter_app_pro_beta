import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/home_screen.dart'; // ← パス修正
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';


final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 通知の初期化
  await AwesomeNotifications().initialize(
    null,
    [
      NotificationChannel(
        channelKey: 'basic_channel',
        channelName: 'Basic Notifications',
        channelDescription: 'Notification channel for basic tests',
        locked: true,
        // ✅ ユーザーがスワイプしないと消えない
        defaultColor: Colors.teal,
        importance: NotificationImportance.High,
        channelShowBadge: true,
      )
    ],
    debug: true,
  );

  // 通知許可リクエスト（Android 13 以降では必須）
  bool isAllowed = await AwesomeNotifications().isNotificationAllowed();
  if (!isAllowed) {
    await AwesomeNotifications().requestPermissionToSendNotifications();
  }


  // ✅ 通知タップ時の処理を設定

  // 通知タップ時の処理をリスナーで設定
  AwesomeNotifications().setListeners(
    onActionReceivedMethod: (receivedAction) async {
      // 🔥 通知タップでホーム画面に遷移
      navigatorKey.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const HomeScreen(csvData: [])),
            (route) => false,
      );
    },
  );

// 🔥 再起動時に通知スケジュールを復元
  await _rescheduleNotifications();

  // ⚡ UI負荷軽減: ステータスバー非表示＆縦固定
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]).then((_) {
    runApp(const MyApp());
  });
}
// 通知スケジュール復元
Future<void> _rescheduleNotifications() async {
  final prefs = await SharedPreferences.getInstance();
  final int? morningHour = prefs.getInt('morning_hour');
  final int? morningMinute = prefs.getInt('morning_minute');
  final int? eveningHour = prefs.getInt('evening_hour');
  final int? eveningMinute = prefs.getInt('evening_minute');

  if (morningHour != null && morningMinute != null) {
    final morningTime = TimeOfDay(hour: morningHour, minute: morningMinute);
    await AwesomeNotifications().createNotification(
      content: NotificationContent(
        id: 1,
        channelKey: 'basic_channel',
        title: '朝の記録時間',
        body: 'おはようございます☀️\n今日の記録✏️を始めましょう',
        notificationLayout: NotificationLayout.Default,
        actionType: ActionType.Default, // 🔥 追加: 通知タップでアプリ起動
        payload: {"navigate": "home"}, // 🔥 ペイロード追加
      ),
      schedule: NotificationCalendar(
        hour: morningTime.hour,
        minute: morningTime.minute,
        second: 0,
        repeats: true,
      ),
    );
  }

  if (eveningHour != null && eveningMinute != null) {
    final eveningTime = TimeOfDay(hour: eveningHour, minute: eveningMinute);
    await AwesomeNotifications().createNotification(
      content: NotificationContent(
        id: 2,
        channelKey: 'basic_channel',
        title: '夜の振り返り',
        body: '1日お疲れ様でした🌙\n気持ちを整えるヒント💡をチェックしてみませんか？',
        notificationLayout: NotificationLayout.Default,
        actionType: ActionType.Default, // 🔥 追加: 通知タップでアプリ起動
        payload: {"navigate": "home"}, // 🔥 ペイロード追加
      ),
      schedule: NotificationCalendar(
        hour: eveningTime.hour,
        minute: eveningTime.minute,
        second: 0,
        repeats: true,
      ),
    );
  }
}


// 通知スケジュール復元
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      debugShowCheckedModeBanner: false,
      title: '幸せ感ナビ',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomeScreen(csvData: []), // 起動後すぐHomeScreen
    );
  }
}

// class SplashScreen extends StatefulWidget {
//   const SplashScreen({Key? key}) : super(key: key);
//
//   @override
//   State<SplashScreen> createState() => _SplashScreenState();
// }
//
// class _SplashScreenState extends State<SplashScreen> {
//   @override
//   void initState() {
//     super.initState();
//
//     // ⚡ 重い処理を遅延実行
//     Future.microtask(() async {
//       await initializeApp();
//       if (!mounted) return;
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (context) => const HomeScreen(csvData: []), // 空配列を渡す
//         ),
//       );
//     });
//   }
//
//   Future<void> initializeApp() async {
//     // 通知初期化
//     await AwesomeNotifications().initialize(
//       null,
//       [
//         NotificationChannel(
//           channelKey: 'basic_channel',
//           channelName: 'Basic Notifications',
//           channelDescription: 'Notification channel for basic tests',
//         )
//       ],
//       debug: true,
//     );
//     // CSV読み込み（重い処理ならここも遅延）
//     await Future.delayed(const Duration(milliseconds: 500));
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return const Scaffold(
//       body: Center(
//         child: CircularProgressIndicator(),
//       ),
//     );
//   }
// }
