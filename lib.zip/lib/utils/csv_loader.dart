import 'dart:convert';
import 'dart:io';

import 'package:csv/csv.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';



/// ───────────────────────────────────────────────
/// 共通ヘルパ – 空行を除外しつつ String 化
/// ───────────────────────────────────────────────
List<List<String>> _sanitizeRows(List<List<dynamic>> rows) => rows
    .where((r) => r.isNotEmpty &&
    r.any((c) => c.toString().trim().isNotEmpty))          // ← 空行フィルタ
    .map((r) => r.map((e) => e.toString()).toList())
    .toList();
/// --------------------------------------------------
/// ⑤ アプリ初回起動時：assets → DocumentDirectory
/// --------------------------------------------------
/// /// assets から初期 CSV をコピー（まだ無い場合だけ）
Future<void> copyAssetCsvIfNotExists() async {
  print('🧪 初期CSVコピー処理を強制実行');

  try {
    final directory = await getApplicationDocumentsDirectory();
    final filePath = '${directory.path}/HappinessLevelDB1_v2.csv';
    final file = File(filePath);

    if (await file.exists()) {
      print('📄 CSVファイルは既に存在しています: $filePath');
      return;
    }

    print('📄 CSVファイルが存在しません。assets からコピーします');
    final csvAsset = await rootBundle.loadString('assets/HappinessLevelDB1_v2.csv');
    await file.writeAsString(csvAsset);
    print('✅ 初期CSVコピー完了: $filePath');
  } catch (e) {
    print('❌ 初期CSVコピー中にエラーが発生: $e');
  }
}

List<List<String>> _robustCsvParse(String raw) {
  List<List<dynamic>> tmp = const CsvToListConverter(eol: '\n').convert(raw);

  List<List<String>> sanitize(List<List<dynamic>> rows) => rows
      .where((r) => r.isNotEmpty && r.any((c) => c.toString().trim().isNotEmpty))
      .map((r) => r
      .map((e) => e
      .toString()
      .replaceAll('"', '')   // ← ★ 追加
      .trim())
      .toList())
      .toList();

  if (tmp.length > 1) return sanitize(tmp);

  // フォールバック
  return sanitize(LineSplitter.split(raw)
      .where((l) => l.trim().isNotEmpty)
      .map((l) => l.split(','))
      .toList());
}

/// アプリ内で共通で使う正しいヘッダー
// CSVヘッダーを外部で使えるように公開
const List<String> _header = [
  '日付',
  '幸せ感レベル',
  'ストレッチ時間',
  'ウォーキング時間',
  '睡眠の質',
  '睡眠時間（時間換算）',
  '睡眠時間（分換算）',
  '睡眠時間（時間）',
  '睡眠時間（分）',
  '寝付き満足度',
  '深い睡眠感',
  '目覚め感',
  'モチベーション',
  '感謝数',
  '感謝1',
  '感謝2',
  '感謝3',
];
// CSVヘッダーを外部で使えるように公開
const header = _header;
const _expectedLen = 17;



/*───────────────────────────────────────────────
  assets ➜ DocumentDirectory へ初期 CSV を撒く
───────────────────────────────────────────────*/
Future<void> ensureCsvSeeded(String filename) async {
  print('🟢 ensureCsvSeeded: called for $filename'); // <- リリースでも出力される
  final dir = await getApplicationDocumentsDirectory();
  final file = File('${dir.path}/$filename');

  if (!await file.exists()) {
    print('📦 assets から $filename をコピー開始');
    try {
      final data = await rootBundle.loadString('assets/$filename');
      await file.writeAsString(data);
      print('✅ コピー成功: ${file.path}');
    } catch (e) {
      print('❌ assets からのコピー失敗: $e');
    }
  } else {
    print('ℹ️ 既にファイル存在: ${file.path}');
  }
}


/*───────────────────────────────────────────────
/// ① DocumentDirectory の最新 CSV を取得（壊れていても復旧）
───────────────────────────────────────────────*/
Future<List<List<String>>> loadLatestCsvData(String filename) async {
  try {
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/$filename');

    if (!await file.exists()) {
      debugPrint('📄 ファイルが存在しません: ${file.path}');
      // ✅ リリースモードでも assets からコピー
      debugPrint('📦 assets から $filename をコピー開始（モード問わず）');
      final assetData = await rootBundle.loadString('assets/$filename');
      await file.writeAsString(assetData);
      debugPrint('✅ assets から $filename をコピー完了: ${file.path}');
    } else {
      debugPrint('ℹ️ 既にファイル存在: ${file.path}');
    }

    // ① 読み込み + パース（空行除外付き）
    final raw = await file.readAsString();
    var data = _robustCsvParse(raw);

    // ② データ行が無ければ再コピーしない
    if (data.length <= 1) {
      debugPrint('⚠️ データ行が無いため、再コピーせず空データとして扱います');
      // ヘッダーだけ追加して返す
      final fixedRows = <List<String>>[];
      fixedRows.add(List<String>.from(_header)); // 正しいヘッダーを最初に
      debugPrint("📄 読み込んだCSV内容(ヘッダーのみ): $fixedRows");
      debugPrint('✅ loadLatestCsvData rows = ${fixedRows.length}');
      return fixedRows;
    }

    // ③ ヘッダー整形 & 列数補正
    final fixedRows = <List<String>>[];
    fixedRows.add(List<String>.from(_header)); // 正しいヘッダーを最初に

    for (var i = 1; i < data.length; i++) {
      var row = List<String>.from(data[i]);

      if (row.length < _expectedLen) {
        row.addAll(List.filled(_expectedLen - row.length, ''));
      } else if (row.length > _expectedLen) {
        row = row.sublist(0, _expectedLen);
      }
      fixedRows.add(row);
    }

    debugPrint("📄 読み込んだCSV内容: $fixedRows");
    debugPrint('✅ loadLatestCsvData rows = ${fixedRows.length}');
    return fixedRows;
  } catch (e, st) {
    debugPrint('❌ CSV 読み込み失敗: $e');
    debugPrintStack(stackTrace: st);
    return [];
  }
}


/// --------------------------------------------------
/// ② assets 直読み（旧 loadCsvAsStringMatrix 互換）
/// --------------------------------------------------
Future<List<List<String>>> loadCsvAsStringMatrix(String assetPath) async =>
    loadCsvFromAssets(assetPath);

Future<List<List<String>>> loadCsvFromAssets(String assetPath) async{
  final raw = await rootBundle.loadString('assets/$assetPath');
  return _robustCsvParse(raw);
}


/*───────────────────────────────────────────────
  FileSystem 読み込み（行列 → String 化・空行除外）
───────────────────────────────────────────────*/
Future<List<List<String>>> loadCsvFromFileSystem(String filename) async {
  final dir = await getApplicationDocumentsDirectory();
  final file = File('${dir.path}/$filename');

  if (!await file.exists()) return [];

  final raw = await file.readAsString();
  return _robustCsvParse(raw);
}

/// --------------------------------------------------
/// ④ Map 形式で欲しい場合（TipsScreen 等の互換性）
/// --------------------------------------------------
Future<List<Map<String,String>>> loadCsvAsMapList(String assetPath) async{
  final matrix = await loadCsvFromAssets(assetPath);
  return toMapList(matrix);
}

List<Map<String, String>> toMapList(List<List<String>> matrix) {
  if (matrix.isEmpty) return [];

  final header = matrix.first.map((h) => h.trim()).toList();
  return matrix.skip(1).map((row) {
    final padded = row.length < header.length
        ? [...row, ...List.filled(header.length - row.length, '')]
        : row.sublist(0, header.length);
    return Map<String, String>.fromIterables(header, padded);
  }).toList();
}



