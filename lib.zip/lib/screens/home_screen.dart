import 'package:flutter/material.dart';
import 'navigation_screen.dart';

/// ホーム画面（軽量版）
class HomeScreen extends StatelessWidget {
  final List<List<dynamic>> csvData;
  const HomeScreen({super.key, required this.csvData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // 背景色のみ（画像を削除）
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                '幸せ感ナビに\nようこそ',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 32, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => NavigationScreen(csvData: csvData),
                    ),
                  );
                },
                child: const Text('ナビゲーション画面へ'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
