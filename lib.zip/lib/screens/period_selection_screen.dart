import 'package:flutter/material.dart';
import 'package:my_android_app/widgets/one_week_chart.dart';
import 'package:my_android_app/widgets/four_weeks_chart.dart';
import 'package:my_android_app/widgets/one_year_chart.dart';

/// 期間選択画面 (1日/1週/4週/1年)
/// ------------------------------------------------------------
class PeriodSelectionScreen extends StatefulWidget {
  final List<List<dynamic>> csvData;

  const PeriodSelectionScreen({super.key, required this.csvData});

  @override
  State<PeriodSelectionScreen> createState() => _PeriodSelectionScreenState();
}

class _PeriodSelectionScreenState extends State<PeriodSelectionScreen> {
  String _selected = '1週間';
  final _options = const ['1日', '1週間', '4週間', '1年'];

  /// 抽出済み csv を "日付" => 行Map に変換 & 日付の " と / を正規化
  List<List<dynamic>> get _sanitizedData {
    return widget.csvData.map((row) {
      if (row.isNotEmpty) {
        row[0] = row[0].toString().replaceAll('"', '').trim();
      }
      return row;
    }).toList();
  }

  void _navigate() {
    final csv = _sanitizedData;
    switch (_selected) {
      case '1週間':
        Navigator.push(context, MaterialPageRoute(builder: (_) => OneWeekChart(csvData: csv)));
        break;
      case '4週間':
        Navigator.push(context, MaterialPageRoute(builder: (_) => FourWeeksChart(csvData: csv)));
        break;
      case '1年':
        Navigator.push(context, MaterialPageRoute(builder: (_) => OneYearChart(csvData: csv)));
        break;
      case '1日':
      default:
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('1日グラフはナビ画面の\u201C1日グラフで見る\u201Dからご覧ください')),
        );
    }
  }

  //--------------------------------------------------------------------
  // UI
  //--------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('期間を選択')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('表示する期間を選んでください', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              DropdownButton<String>(
                value: _selected,
                items: _options.map((p) => DropdownMenuItem(value: p, child: Text(p))).toList(),
                onChanged: (v) => setState(() => _selected = v!),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _navigate,
                  child: const Text('保存データを読み込み📊を表示'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
